//All database calls should go in here after you're done making them. That way, they can all be exported statically
//or as a function. But either way, it should really clean up routes.